import { useEffect, useState } from 'react';
import { Check, X } from 'lucide-react';
import styles from '../styles/BolaModal.module.css'; // qayta ishlatamiz
import { getText } from '../i18n/translations';

export default function SkladModal({ isOpen, onClose, onSave, initialData }) {
  const [formData, setFormData] = useState({
    nomi: '',
    hajm: '',
    hajm_birlik: 'kg'
  });

  useEffect(() => {
    if (initialData) {
      setFormData({
        nomi: initialData.nomi || '',
        hajm: initialData.hajm || '',
        hajm_birlik: initialData.hajm_birlik || 'kg',
      });
    } else {
      setFormData({ nomi: '', hajm: '', hajm_birlik: 'kg' });
    }
  }, [initialData]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = () => {
    onSave(formData);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className={styles.modal}>
      <div className={styles.modal__content}>
        <h3 className={styles.modal__title}>
          {initialData ? getText('editProduct') : getText('newProduct')}
        </h3>

        <div className={styles.modal__form}>
          <input
            name="nomi"
            value={formData.nomi}
            onChange={handleChange}
            placeholder={getText('productNamePlaceholder')}
          />
          <input
            name="hajm"
            type="number"
            value={formData.hajm}
            onChange={handleChange}
            placeholder={getText('volumePlaceholder')}
          />
          {/* value — bazadagi qiymat, o'zgarmaydi; faqat ko'rinadigan nomi tarjima qilinadi. */}
          <select name="hajm_birlik" value={formData.hajm_birlik} onChange={handleChange}>
            <option value="kg">{getText('unitKg')}</option>
            <option value="litr">{getText('unitLitr')}</option>
            <option value="dona">{getText('unitDona')}</option>
            <option value="metr">{getText('unitMetr')}</option>
            <option value={"bog'"}>{getText('unitBogh')}</option>
            <option value="gramm">{getText('unitGramm')}</option>
          </select>
        </div>

        <div className={styles.modal__buttons}>
          <button onClick={handleSubmit}><Check size={16} /> {getText('save')}</button>
          <button onClick={onClose}><X size={16} /> {getText('cancel')}</button>
        </div>
      </div>
    </div>
  );
}
